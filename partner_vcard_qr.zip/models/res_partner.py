import qrcode
import base64
from io import BytesIO
from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'
    
    vcard_qr_code = fields.Binary(
        string="QR Code",
        compute='_compute_vcard_qr_code',
        store=False
    )
    
    @api.depends('name', 'phone', 'mobile', 'email', 'street', 'city', 'zip', 'country_id', 'function')
    def _compute_vcard_qr_code(self):
        for partner in self:
            # Vytvoření vCard dat
            vcard_lines = ['BEGIN:VCARD', 'VERSION:3.0']
            
            # Jméno
            if partner.name:
                vcard_lines.append(f'FN:{partner.name}')
                # Strukturované jméno přidáme jen pokud lze rozdělit
                name_parts = partner.name.strip().split(' ')
                if len(name_parts) >= 2:
                    # Předpokládáme: poslední část = příjmení, zbytek = křestní
                    last_name = name_parts[-1]
                    first_names = ' '.join(name_parts[:-1])
                    vcard_lines.append(f'N:{last_name};{first_names};;;')
                # Pokud jen jedno slovo, N pole vynecháme úplně
            
            # Organizace
            if partner.parent_id and partner.parent_id.is_company:
                vcard_lines.append(f'ORG:{partner.parent_id.name}')
            elif partner.is_company:
                vcard_lines.append(f'ORG:{partner.name}')
            
            # Pozice
            if partner.function:
                vcard_lines.append(f'TITLE:{partner.function}')
            
            # Telefon
            if partner.phone:
                vcard_lines.append(f'TEL;TYPE=WORK,VOICE:{partner.phone}')
            if partner.mobile:
                vcard_lines.append(f'TEL;TYPE=CELL:{partner.mobile}')
            
            # Email
            if partner.email:
                vcard_lines.append(f'EMAIL;TYPE=INTERNET:{partner.email}')
            
            # Adresa
            if partner.street or partner.city or partner.zip:
                street = partner.street or ''
                city = partner.city or ''
                zip_code = partner.zip or ''
                country = partner.country_id.name if partner.country_id else ''
                state = partner.state_id.name if partner.state_id else ''
                vcard_lines.append(f'ADR;TYPE=WORK:;;{street};{city};{state};{zip_code};{country}')
            
            # URL/Web
            if partner.website:
                vcard_lines.append(f'URL:{partner.website}')
            
            vcard_lines.append('END:VCARD')
            vcard_data = '\n'.join(vcard_lines)
            
            # Generování QR kódu
            try:
                qr = qrcode.QRCode(
                    version=1,
                    error_correction=qrcode.constants.ERROR_CORRECT_L,
                    box_size=10,
                    border=4,
                )
                qr.add_data(vcard_data)
                qr.make(fit=True)
                
                img = qr.make_image(fill_color="black", back_color="white")
                buffer = BytesIO()
                img.save(buffer, format='PNG')
                partner.vcard_qr_code = base64.b64encode(buffer.getvalue())
            except Exception:
                partner.vcard_qr_code = False
